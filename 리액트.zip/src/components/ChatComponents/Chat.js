export default function Chat() {


    return(
        <>
            <p>실시간 채팅 페이지 입니다.</p>
        </>
    )
}